#pragma once
#include <sstream>
#include "../../keyspace-hashtable/KeySpace.h"


void handleDrop(std::stringstream &ss, KeySpace &db);
