#pragma once
#include <sstream>
#include "../../keyspace-hashtable/KeySpace.h"


void handleShow(std::stringstream &ss, KeySpace &db);
