#pragma once
#include <sstream>
#include "../../keyspace-hashtable/KeySpace.h"


void handleSearch(std::stringstream &ss, KeySpace &db);
