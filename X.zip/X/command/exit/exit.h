#pragma once
#include <sstream>
#include "../../keyspace-hashtable/KeySpace.h"



bool handleExit(std::stringstream &ss, KeySpace &db);
