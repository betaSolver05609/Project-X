#pragma once
#include <string>
#include <vector>

std::vector<std::vector<float>> parseJsonFile(const std::string& filepath);
