#pragma once
#include <string>
#include <vector>

std::vector<std::vector<float>> parseCsvFile(const std::string& filepath);
