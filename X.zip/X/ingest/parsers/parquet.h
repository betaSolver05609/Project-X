// #pragma once
// #include <string>
// #include <vector>

// std::vector<std::vector<float>> parseParquetFile(const std::string& filepath);
